Gallery Metaboxes Class
========================

Used in many WPExplorer themes for adding post/page galleries
