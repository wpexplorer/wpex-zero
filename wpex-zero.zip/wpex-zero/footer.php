<?php
/**
 * The template for displaying the footer and closing elements starting in header.php
 *
 * @package		Zero
 * @author		Alexander Clarke
 * @copyright	Copyright (c) 2014, Symple Workz LLC
 * @link		http://www.wpexplorer.com
 * @since		1.0.0
 */ ?>

	</div><!-- #content -->
</div><!-- #wrap -->

<?php wp_footer(); ?>
</body>
</html>